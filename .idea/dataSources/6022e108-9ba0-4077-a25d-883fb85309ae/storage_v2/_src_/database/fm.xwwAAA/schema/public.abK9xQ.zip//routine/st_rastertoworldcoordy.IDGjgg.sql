CREATE FUNCTION st_rastertoworldcoordy(rast raster, xr integer, yr integer)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

