CREATE FUNCTION postgis_scripts_build_date()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2018-03-04 03:35:11'::text AS version
$$;

