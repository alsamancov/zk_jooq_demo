CREATE FUNCTION raster_contained_by_geometry(raster, geometry)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::geometry OPERATOR(public.@) $2
$$;

