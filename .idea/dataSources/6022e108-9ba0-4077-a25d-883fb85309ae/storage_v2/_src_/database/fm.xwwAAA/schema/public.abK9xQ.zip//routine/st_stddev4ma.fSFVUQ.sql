CREATE FUNCTION st_stddev4ma(value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[])
  RETURNS double precision
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT stddev(unnest) FROM unnest($1)
$$;

