CREATE FUNCTION st_distinct4ma(value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[])
  RETURNS double precision
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT COUNT(DISTINCT unnest)::double precision FROM unnest($1)
$$;

