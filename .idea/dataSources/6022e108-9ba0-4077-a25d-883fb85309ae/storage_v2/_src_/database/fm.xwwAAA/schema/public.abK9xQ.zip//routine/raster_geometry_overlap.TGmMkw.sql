CREATE FUNCTION raster_geometry_overlap(raster, geometry)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::geometry OPERATOR(public.&&) $2
$$;

