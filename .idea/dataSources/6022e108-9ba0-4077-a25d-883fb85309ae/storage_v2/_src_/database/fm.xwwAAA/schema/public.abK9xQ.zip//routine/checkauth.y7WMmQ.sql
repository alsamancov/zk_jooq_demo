CREATE FUNCTION checkauth(text, text)
  RETURNS integer
LANGUAGE SQL
AS $$
SELECT CheckAuth('', $1, $2)
$$;

