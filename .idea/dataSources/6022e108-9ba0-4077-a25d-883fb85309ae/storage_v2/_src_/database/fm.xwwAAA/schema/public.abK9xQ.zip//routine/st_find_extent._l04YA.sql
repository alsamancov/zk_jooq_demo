CREATE FUNCTION st_find_extent(text, text, text)
  RETURNS box2d
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Find_Extent', 'ST_FindExtent', '2.2.0');
    SELECT public.ST_FindExtent($1,$2,$3);
$$;

