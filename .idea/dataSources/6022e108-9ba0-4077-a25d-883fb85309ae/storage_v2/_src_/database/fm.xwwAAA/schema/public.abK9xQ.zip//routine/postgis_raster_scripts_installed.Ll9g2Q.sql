CREATE FUNCTION postgis_raster_scripts_installed()
  RETURNS text
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT '2.4.3'::text AS version
$$;

