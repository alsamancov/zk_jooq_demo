CREATE RULE geometry_columns_insert AS
    ON INSERT TO public.geometry_columns DO INSTEAD NOTHING;

