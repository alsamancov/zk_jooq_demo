CREATE FUNCTION st_distance(geography, geography)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_Distance($1, $2, 0.0, true)
$$;

