CREATE FUNCTION st_locate_along_measure(geometry, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_locate_between_measures($1, $2, $2)
$$;

