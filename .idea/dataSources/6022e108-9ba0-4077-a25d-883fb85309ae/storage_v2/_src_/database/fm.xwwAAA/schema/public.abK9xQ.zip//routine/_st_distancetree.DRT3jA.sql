CREATE FUNCTION "_st_distancetree"(geography, geography)
  RETURNS double precision
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT public._ST_DistanceTree($1, $2, 0.0, true)
$$;

