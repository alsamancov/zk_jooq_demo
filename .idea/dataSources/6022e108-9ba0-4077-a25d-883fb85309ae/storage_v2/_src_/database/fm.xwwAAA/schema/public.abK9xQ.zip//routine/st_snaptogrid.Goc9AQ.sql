CREATE FUNCTION st_snaptogrid(geometry, double precision, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
SELECT public.ST_SnapToGrid($1, 0, 0, $2, $3)
$$;

