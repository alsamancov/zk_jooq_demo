CREATE FUNCTION raster_below(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::geometry <<| $2::geometry
$$;

