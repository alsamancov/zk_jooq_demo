CREATE FUNCTION st_rastertoworldcoordx(rast raster, xr integer, yr integer)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT longitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

