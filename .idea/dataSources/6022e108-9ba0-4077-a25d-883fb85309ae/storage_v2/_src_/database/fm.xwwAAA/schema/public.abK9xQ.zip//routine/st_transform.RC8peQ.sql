CREATE FUNCTION st_transform(geom geometry, to_proj text)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.postgis_transform_geometry($1, proj4text, $2, 0)
FROM spatial_ref_sys WHERE srid=public.ST_SRID($1);
$$;

