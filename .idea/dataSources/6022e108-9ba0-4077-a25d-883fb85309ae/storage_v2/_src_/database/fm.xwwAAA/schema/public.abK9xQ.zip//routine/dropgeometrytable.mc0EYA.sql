CREATE FUNCTION dropgeometrytable(table_name character varying)
  RETURNS text
STRICT
LANGUAGE SQL
AS $$
SELECT public.DropGeometryTable('','',$1)
$$;

