CREATE FUNCTION st_findextent(text, text)
  RETURNS box2d
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE plpgsql
AS $$
DECLARE
	tablename alias for $1;
	columnname alias for $2;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT public.ST_Extent("' || columnname || '") As extent FROM "' || tablename || '"' LOOP
		return myrec.extent;
	END LOOP;
END;
$$;

