CREATE FUNCTION st_curvetoline(geometry)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ST_CurveToLine($1, 32::integer)
$$;

