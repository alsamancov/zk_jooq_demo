CREATE FUNCTION st_geomfromgeohash(text, integer DEFAULT NULL::integer)
  RETURNS geometry
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT CAST(public.ST_Box2dFromGeoHash($1, $2) AS geometry);
$$;

